/**
 * Created by slash on 28.04.16.
 */

var angular_scope;

'use strict';
angular.module('horoshihClub', ['ngCookies']);

angular.module('horoshihClub')
    .controller('mainController', ['$scope','EventService', function($scope, EventService) {

        angular_scope = $scope;

        $scope.startGame = function () {
            console.log("Start game from controller");

            EventService.registerEvent(EventService.START_GAME, { userAgent : navigator.userAgent,
                                                                    os : navigator.oscpu,
                                                                    lang : navigator.language});
            gamePhase = 1;
            window.location.href = "#";
            newGame();
        };

        $scope.showNewGameMessage = function () {
            gamePhase = 0;
            window.location.href = "#newGameMessage";
            if (this.hasOwnProperty("score")) {
                console.log("Game score: ", score);
                EventService.registerEvent(EventService.END_GAME, { score : $scope.score});
            } else {
                console.log("Score not defined: ");
            }

        }
    }]);


angular.module('horoshihClub')
    .service('EventService', ['$http', function($http) {

        this.REGISTER = 100;
        this.CONNECT = 200;
        this.START_GAME = 300;
        this.END_GAME = 400;
        this.LOCATION = 500;
        var url = '/api/registerevent';

        this.registerEvent = function (event, eventData) {
            var data={};
            if (event != null) {
                data['event']=event;
            }
            if (eventData != null) {
                data['eventData'] = eventData;
            }

            $http.post(url, data)
                .then ( function (response) {
                    // sucess
                }, function (response) {
                    // error
                });
        };
    }]);

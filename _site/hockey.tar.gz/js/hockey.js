/**
 * Created by DmitryGood on 28.04.16.
 * (C) All rights reserved.
 */

// YI compressor
/// Debug objects
var DebugObject = function () {
    var variables = {};

    this.getString = function () {
        var result = "";
        for ( var name in variables) {
            result += name + " : " + variables[name] + "\n";
        }
        return result;
    };

    this.log = function(name, value) {
        variables[name] = value;
        return true;
    };

    this.clear = function () {
        variables = {};
    }
};

/// Working objects

function ScoreObject () {   // object for score
    var p1 = 0;
    var p2 = 0;

    this.clear = function () {
        p1 = 0;
        p2 = 0;
    };

    this.increaseP1 = function() {
        p1 += 1;
    };

    this.increaseP2 = function () {
        p2 += 1;
    };

    this.getScoreString = function () {
        return p1 + " : " + p2;
    };

    this.p1 = function () {
        return p1;
    };

    this.p2 = function () {
        return p2;
    };

    this.draw = function (ctx) {
        ctx.font = "28px monospace";
        ctx.strokeStyle = "black";
        ctx.strokeText(this.getScoreString(), 20, 20);
    }
}


    function MovingHero (coordinates, sizes, initial_speed, move_limits, imageAddress, self, power, updateFunction, rotate) {
        var coord = {x : coordinates.x, y : coordinates.y};
        var size = sizes;
        var hitRadius = Math.sqrt(Math.pow(size.x /2, 2) + Math.pow(size.y /2, 2)) * 0.9;
        var speed = initial_speed;
        var limits = move_limits;
        var image = null;
        this.self = self || false;
        this.power = power || 50;           // default power
        // Function updateFunction :
        // takes: new screen size: {width, height} and gate position {left_border, right_border, top_line, bottom_line}
        // returns {coord: {x,y} , sizes: {x:y}, limits: {top, left, bottom, right}
        this.updateFunction = updateFunction || function (screen_size, gate_position) {return null}; // returns {coord: {x,y} , sizes: {x:y}, limits:
        this.rotate = rotate || false;
        this.direction = 1;                 // for future direction
        var img = new Image();
        img.src = imageAddress;

        img.addEventListener("load", function () {
            image = img;
        });


        this.drawHero = function (ctx) {
            if (image) {
                ctx.drawImage(image, coord.x, coord.y, size.x, size.y)
            }
        };

        this.moveHero = function () {
            coord.x += speed.x;
            coord.y += speed.y;
            var newX = coord.x + speed.x;
            var newY = coord.y + speed.y;

            if (newX < limits.left || newX + size.x > limits.right  ) {
                speed.x = - speed.x;
            } else {
                coord.x = newX;
            }

            if (newY < limits.top || newY + size.y > limits.bottom  ) {
                speed.y = - speed.y;
            } else {
                coord.y = newY;
            }
        };

        this.checkCollision = function (x, y, r) {   // return TRUE if collision detected
            var distance = Math.sqrt(Math.pow((coord.x + size.x /2) - x, 2) + Math.pow((coord.y + size.y /2) - y, 2));
            return distance < (r + hitRadius);
        };

        this.isSelf = function () {
            return this.self;
        };

        this.getHitSpeed = function(x, y) { // return hit power to destination point
            var dx = x - coord.x;
            var dy = y - coord.y;

            var k = Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2)) / this.power;
            var rand = Math.random() * 0.4 + 0.6;                 // randomize power
            //var horiz_random = Math.random() * 0.8 + 0.6;       // ослабление точности удара
            //return { x : dx / ( k * rand) / (horiz_random + 0.6), y : dy * horiz_random / (k * rand)};
            return { x : dx / ( k * rand), y : dy / (k * rand)};

        };

        // the function called when screen sizes changed to update hero position, size, and zone
        this.updateHeroState = function(screen_size, gate_position) {
            var new_state = this.updateFunction(screen_size, gate_position);
            if (new_state) {
                // scale speed
                var scale = new_state.sizes.x / size.x;
                speed = { x: speed.x *= scale, y : speed.y *= scale};
                // assign new parameters
                coord = new_state.coord;
                size = new_state.sizes;
                limits = new_state.limits;

            }
            // if new_state == NULL - update nothing
        }

    }

/*
 The function to draw game field
 */
function Field() {
    var gate = null;

    if ( gate == null ) {     // have to load image first
        var image = new Image();
        image.src = "images/hockey-gates.png";
        image.addEventListener("load", function () {
            gate = image;
        })
    }

    this.draw = function (ctx, state) {
        if (gate) {
            var x = state.gate.left;

            var pic_w = gate.width;
            var pic_h = gate.height;

            var scale = state.gate_width / pic_w;
            var new_h = pic_h * scale
            var top = state.gate.top_line - new_h;
            ctx.drawImage(gate, x , top, pic_w * scale, new_h );

            // draw own gates
            var y = state.gate.bottom_line + new_h;
            ctx.save();
            ctx.translate(state.gate.right, y);
            ctx.rotate(Math.PI / 180 * 180);
            ctx.drawImage(gate, 0 , 0, pic_w * scale, new_h);
            ctx.restore();
        }
    }
}

// Dont use except event types
function MessageQueue () {
    var events =[];

    this.hasEvent = function () {
        return events.length > 0;
    };

    this.getEvents = function () {
        return Object.create(events);
    };

    this.clear = function () {
        events = [];
    };

    this.raiseEvent = function (event) {
        events.push(event);
    }
}
// Static constants
MessageQueue.EVENT_GOAL = 1;
MessageQueue.EVENT_BAR = 2;
MessageQueue.EVENT_SELF_GOAL = 3;


function FieldEventZone (updateFunction, event, debugColor) {
    //var position = {left: left, top : top, right: right, bottom : bottom };
    var position = {left: 0, top : 0, right: 0, bottom : 0 };
    this.updateFunction = updateFunction || function (state) { return null;};
    var ev = event;
    var color;
    // create debug color
    if ( ! debugColor) {
        if (ev == MessageQueue.EVENT_SELF_GOAL) {  // red
            color = "rgba(255, 174, 159, 0.5)";
        } else if (ev == MessageQueue.EVENT_GOAL ) {
            color = "rgba(157, 255, 170, 0.5)";
        } else if (ev == MessageQueue.EVENT_BAR) {
            color = "rgba(141, 172, 255, 0.5)";
        } else {
            color = "rgba(195, 191, 195, 0.5)";
        }
    } else {
        color = debugColor;
    }

    this.updatePosition = function (state) {
        var new_position = this.updateFunction(state);
        if (new_position) {
            position = new_position;
        }
    };

    this.checkEvent = function ( queue, x, y, r) {
        if (x+r > position.left && x-r < position.right && y+r > position.top && y-r < position.bottom) {
            queue.raiseEvent(ev);
        }
    };

    this.checkCollision = function ( x, y, r) {
        if (x+r > position.left && x-r < position.right && y+r > position.top && y-r < position.bottom) {
            return true;
        }
        return false;
    };

    this.checkTrajectoryCollision = function(x, y, r, speedX, speedY) {

    };

    this.eventType = function () {
        return ev;
    };

    this.debugShowZone = function (ctx) {
        ctx.beginPath();
        ctx.fillStyle = color;
        ctx.fillRect(position.left, position.top, position.right - position.left, position.bottom - position.top);
        ctx.closePath();

    }
}

function GameState(width, heigh) {
    this.size = {width : 0, height : 0 };
    this.gate = {left : 0, right: 0, top_line : 0, bottom_line : 0};
    this.center = { x : 0, y : 0};
    this.gate_picture_width = 540;   // constant
    this.gate_picture_height = 400;



    this.update = function (width, heigh) {
        this.gate_width = width / 3.6;              // new gate size
        var scale = this.gate_width / this.gate_picture_width;
        var gate_visible_part = this.gate_picture_height * scale * 0.4;
        this.size = { width : width, height : heigh };
        this.center = { x : width / 2, y : heigh / 2};
        this.gate = {   left : this.center.x - this.gate_width / 2,
            right: this.center.x + this.gate_width / 2,
            top_line : gate_visible_part,
            bottom_line : heigh - gate_visible_part};
    };

    this.update(width, heigh);
}

var drawLimits = {x: 0, y: 0 };
var ballRadius = 20;
var ballCoord = {x : 0, y: 0};
var ballSpeed = {x : 0, y: 0};
var ballWeight = 30;
var forceBase = 1;
var friction=0.98;
var hero = null;
var heroForce = { x: 10, y: 40};
var heroes = [];
var field = new Field();
var debugMaxSpeedX = 0;
var debugMaxSpeedY = 0;

var deviceOrientation = null;
var debug = new DebugObject();
var score = new ScoreObject();
var fieldZones = [];
var gamePhase = 0 ; // 0 - game not started, 1 - game in progress
var maxScore = 5;

// Drawing data
var ctx;
var state;          // Game state

///--------------------------///
// Drawing zone
///--------------------------///

/*      Screen functions
 */
function resizeCanvas() {
    var x = window.innerWidth-6;
    var y = window.innerHeight-6;

    // ajust canvas to the size of the screen
    var desiredRatio = 1.44;
    var ratio = y / x;
    var k = 0.2;
    if ( ratio < 1.44 * (1 - k) ) {
        drawLimits.x = y / desiredRatio;
        drawLimits.y = y;
    } else if (Math.abs(ratio - desiredRatio)/ desiredRatio < k) {
        drawLimits.x = x;
        drawLimits.y = y;
    } else {
        drawLimits.x = x;
        drawLimits.y = x * desiredRatio;
    }

    con.width = drawLimits.x;
    con.height = drawLimits.y;

    // calculate scale ratio
    var scale = 1;
    if (state) {
        scale = drawLimits.x / state.size.width;
    }

    state = new GameState(drawLimits.x , drawLimits.y);  // Initialize game state object

    // center & update the ball
    centerTheBall();
    ballRadius = state.size.width / 60;
    ballSpeed = { x : ballSpeed.x *= scale, y: ballSpeed.y *= scale};

    // Update heroes
    for (var hero in heroes) {
        if (heroes[hero] && heroes[hero].hasOwnProperty("updateHeroState")) {
            heroes[hero].updateHeroState(state.size, state.gate)
        }
    }

    // update game zones
    for (var zone in fieldZones) {
        if (fieldZones[zone] && fieldZones[zone].hasOwnProperty("updatePosition")) {
            fieldZones[zone].updatePosition(state);
        }
    }

}

function centerTheBall() {
    ballCoord = { x: state.center.x, y: state.center.y };
    ballSpeed = { x: 0, y: 0};
}

/*
 *    Draw functions
 */
function initDraw () {

    // init screen & game control functions

    con = document.getElementById("draw_area");
    if (con) {
        // init draw context
        ctx = con.getContext("2d");
    }
    resizeCanvas();             // ARTEFACT: we need make initial resize to initialize all screen state variables

    // Create a new FULLTILT Promise for e.g. *compass*-based deviceorientation data
    var orienataionPromise = new FULLTILT.getDeviceOrientation({ 'type': 'world' });

    orienataionPromise
        .then (function (controller) {
            deviceOrientation = controller;
        } , function () {});

}

function newGame() {        // all initialization procedures to start a new game
    score.clear();          // clear score

    heroes = [];            // reinitialize the heroes

    // create heroes
    var hero1 = new MovingHero (             // Player 2 - saver
        { x: 40, y : 110 },
        { x: 100 * 0.9, y : 150 * 0.9},
        { x: 3.0, y : 2.0 },
        { top: 100, left: 30, right: drawLimits.x - 100, bottom : 350 },
        "images/hockey-player.png",
        false,
        40,
        // takes: new screen size: {width, height} and gate position {left_border, right_border, top_line, bottom_line}
        // returns {coord: {x,y} , sizes: {x:y}, limits: {top, left, bottom, right}
        function (screen_size, gate_position) {
            var sizeYtoX = 1.5;
            var limits = {
                top : screen_size.height / 8,
                left : screen_size.width / 30,
                bottom : screen_size.height / 10 * 3,
                right : screen_size.width * 0.8
            };
            return {
                coord : {
                    x : limits.left * 1.5,
                    y : limits.top * 1.1
                },
                sizes : {
                    x : screen_size.width / 12 * 0.9,
                    y : screen_size.width / 12 * 0.9 * sizeYtoX,
                },
                limits : limits
            }

        }
    );

    var hero2 = new MovingHero(             // Player 2 - attacker
        { x: 200, y : 350},
        { x: 100, y : 150},
        { x: -5.0, y : 1.0},
        { top: 300, left: 100, right: drawLimits.x - 120, bottom : 600 },
        "images/hockey-player.png",
        false,
        50,
        // takes: new screen size: {width, height} and gate position {left_border, right_border, top_line, bottom_line}
        // returns {coord: {x,y} , sizes: {x:y}, limits: {top, left, bottom, right}
        function (screen_size, gate_position) {
            var sizeYtoX = 1.5;
            var limits = {
                top : screen_size.height / 4,
                left : screen_size.width / 9,
                bottom : screen_size.height / 2.5,
                right : screen_size.width * 0.9
            };
            return {
                coord : {
                    x : limits.left * 1.1,
                    y : limits.top * 1.1
                },
                sizes : {
                    x : screen_size.width / 12,
                    y : screen_size.width / 12 * sizeYtoX,
                },
                limits : limits
            }

        }
    );

    var hero3 = new MovingHero(             // Player 2 goalier
        { x: 380, y : 50},                              // initial coordinates
        { x: 90, y : 90},                               // picture size
        { x: 3.0, y : 0},                             // initial speed
        { top: 40, left: 380, right: 600, bottom : 80 },// hero moving zone
        "images/hockey-goalie.png",                     // image
        false,                                          // if Self-player: TRUE - self, FALSE - competitor
        30,                                              // force
        // takes: new screen size: {width, height} and gate position {left_border, right_border, top_line, bottom_line}
        // returns {coord: {x,y} , sizes: {x:y}, limits: {top, left, bottom, right}
        function (screen_size, gate_position) {
            var sizeYtoX = 1;
            var sizeY = screen_size.height / 15;
            var limits = {
                top : gate_position.top_line * 2 /3,
                left : gate_position.left,
                bottom : gate_position.top_line + sizeY * 1.1,
                right : gate_position.right
            };
            return {
                coord : {
                    x : limits.left * 1.1,
                    y : limits.top * 1.1
                },
                sizes : {
                    x : sizeY / sizeYtoX,
                    y : sizeY
                },
                limits : limits
            }

        }
    );

    var left_gate_limit = drawLimits.x / 2 - 270/2;
    var right_gate_limit = drawLimits.x / 2 + 270/2;
    var bottom_gate_limit = drawLimits.y - 80;

    // Player goalier
    var hero4 = new MovingHero(
        { x: left_gate_limit + 30, y : bottom_gate_limit - 100},                              // initial coordinates
        { x: 130, y : 130},                               // picture size
        { x: 4.0, y : 0},                             // initial speed
        { top: bottom_gate_limit - 110, left: left_gate_limit, right: right_gate_limit, bottom : bottom_gate_limit - 90 },// hero moving zone
        "images/hockey-goalie.png",
        true,
        30,
        // takes: new screen size: {width, height} and gate position {left_border, right_border, top_line, bottom_line}
        // returns {coord: {x,y} , sizes: {x:y}, limits: {top, left, bottom, right}
        function (screen_size, gate_position) {
            var sizeYtoX = 1;
            var sizeY = screen_size.height / 12;
            var lineDist = (screen_size.height - gate_position.bottom_line) * 2 / 3 ;
            var limits = {
                top :  screen_size.height - lineDist - sizeY * 1.1,
                left : gate_position.left,
                bottom : gate_position.bottom_line ,
                right : gate_position.right
            };
            return {
                coord : {
                    x : limits.left + 2,
                    y : limits.top + 2
                },
                sizes : {
                    x : sizeY / sizeYtoX,
                    y : sizeY
                },
                limits : limits
            }

        }
    );

    heroes.push(hero1);
    heroes.push(hero2);
    heroes.push(hero3);
    heroes.push(hero4);

    // initialize & create field zones

    fieldZones = [];
    var gate_bar_width = state.size.width / 30;
    var gate_bar_height = state.gate.top_line / 2;
    // Player 2 zones

    var zone1 = new FieldEventZone( function (state) {
            return {
                left: state.gate.left,
                top : gate_bar_height,
                right: state.gate.right,
                bottom : state.gate.top_line }
        },
        MessageQueue.EVENT_GOAL );


    fieldZones.push(zone1);
    var zone2 = new FieldEventZone( function (state) {
            return {
                left: state.gate.left - gate_bar_width,
                top : 0,
                right:  state.gate.right + gate_bar_width,
                bottom : gate_bar_height }
        },
        MessageQueue.EVENT_BAR ); // wall behind
    fieldZones.push(zone2);
    var zone3 = new FieldEventZone( function (state) {
            return {
                left: state.gate.left - gate_bar_width,
                top : gate_bar_height,
                right:  state.gate.left,
                bottom : state.gate.top_line * 1.1 }
        },
        MessageQueue.EVENT_BAR ); // left wall
    fieldZones.push(zone3);
    var zone4 = new FieldEventZone( function (state) {
            return {
                left: state.gate.right,
                top : gate_bar_height,
                right:  state.gate.right + gate_bar_width,
                bottom : state.gate.top_line * 1.1 }
        },
        MessageQueue.EVENT_BAR ); // right wall
    fieldZones.push(zone4);

    // Player 1 zones

    var zone5 = new FieldEventZone( function (state) {
            return {
                left: state.gate.left,
                top : state.gate.bottom_line,
                right:  state.gate.right,
                bottom : state.gate.bottom_line + gate_bar_height }
        },
        MessageQueue.EVENT_SELF_GOAL );
    fieldZones.push(zone5);
    // Gate borders
    var zone6 = new FieldEventZone( function (state) {
            return {
                left: state.gate.left - gate_bar_width,
                top : state.gate.bottom_line + gate_bar_height,
                right:  state.gate.right + gate_bar_width,
                bottom : state.gate.bottom_line + state.size.height }
        },
        MessageQueue.EVENT_BAR );
    fieldZones.push(zone6);

    var zone7 = new FieldEventZone( function (state) {
            return {
                left: state.gate.left - gate_bar_width,
                top : state.gate.bottom_line - gate_bar_height / 5,
                right:  state.gate.left,
                bottom : state.gate.bottom_line + gate_bar_height }
        },
        MessageQueue.EVENT_BAR );
    fieldZones.push(zone7);

    var zone8 = new FieldEventZone( function (state) {
            return {
                left: state.gate.right,
                top : state.gate.bottom_line - gate_bar_height / 5,
                right:  state.gate.right + gate_bar_width,
                bottom : state.gate.bottom_line + gate_bar_height }
        },
        MessageQueue.EVENT_BAR );
    fieldZones.push(zone8);

    resizeCanvas();             // adjust game artefacts position to screen sizes

    // start new game
    drawScreen();           // Start drawing

}   // end of newGame() function


function drawScreen() {      // Main game loop

    if (gamePhase == 1) {   // redraw the screen only if game is active
        // clear screen
        ctx.clearRect(0, 0, drawLimits.x, drawLimits.y);

        field.draw(ctx, state);

        ctx.beginPath();
        ctx.fillStyle = '#706e6c';
        ctx.strokeStyle = "rgba(0, 0, 0, 0.96)";
        ctx.lineWidth = 2;
        ctx.arc(ballCoord.x, ballCoord.y, ballRadius, 0, Math.PI * 2, true);
        ctx.fill();
        ctx.stroke();

        // Draw hero
        for (var h in heroes) {
            if (heroes[h]) {
                heroes[h].drawHero(ctx);
            }
        }

        // DEBUG - draw zones
        /*
         if (fieldZones.length > 0) {
         for (var zone in fieldZones) {
         fieldZones[zone].debugShowZone(ctx);
         }
         }
         */

        // Update game state
        update();

        //debug.log("limit X:", drawLimits.x.toFixed(1));
        //debug.log("limit Y:", drawLimits.y.toFixed(1));
        //debugMessage(ctx);
        score.draw(ctx);

        requestAnimationFrame(drawScreen)
    }
}

function update() {
    var xForce = 0;
    var yForce = 0;

    if (deviceOrientation) {
        // Obtain the *screen-adjusted* normalized device rotation
        // as Quaternion, Rotation Matrix and Euler Angles objects
        // from our FULLTILT.DeviceOrientation object
        var euler = deviceOrientation.getScreenAdjustedEuler();

        // do math
        // X
        var x = euler.gamma;
        var y = euler.beta;
        var angle = 0;
        var len = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
        if (x != 0) {
            angle = Math.atan(y / x);
            if (x < 0) {
                angle = Math.PI + angle;

            }
        } else {
            angle = Math.PI /2 * Math.sign(y);
        }

        xForce = len * Math.cos(angle);
        yForce = len * Math.sin(angle);
        //debug.log("ForceX", xForce.toFixed(2));
        //debug.log("ForceY", yForce.toFixed(2));

    }

    // update ball speed
    ballSpeed.x +=xForce*forceBase/ballWeight;
    ballSpeed.y +=yForce*forceBase/ballWeight;
    // apply friction
    ballSpeed.x *= friction;
    ballSpeed.y *= friction;
    if (Math.abs(ballSpeed.x) > Math.abs(debugMaxSpeedX) ) { debugMaxSpeedX = ballSpeed.x}
    if (Math.abs(ballSpeed.y) > Math.abs(debugMaxSpeedY) ) { debugMaxSpeedY = ballSpeed.y}

    //debug.log('MaxSpeedX', (debugMaxSpeedX).toFixed(2));
    //debug.log('MaxSpeedY', (debugMaxSpeedY).toFixed(2));

    // update ball position
    ballCoord.x += ballSpeed.x; // Axis Y of the device is going up, so Y rotating changes X on the screen
    ballCoord.y += ballSpeed.y; // Axis Y of the device is going up, so Y rotating changes X on the screen

    // hit the walls
    if ( (ballCoord.x - ballRadius) <= 0 || ( ballCoord.x + ballRadius) >= drawLimits.x ) {
        ballCoord.x -= ballSpeed.x;
        ballSpeed.x = - ballSpeed.x;
    }

    if ( (ballCoord.y - ballRadius) <= 0 || ( ballCoord.y + ballRadius) >= drawLimits.y ) {
        ballCoord.y -= ballSpeed.y;
        ballSpeed.y = - ballSpeed.y;
    }

    // check ball outside the field
    if ( ballCoord.x < ballRadius) {ballCoord.x = ballRadius};
    if ( ballCoord.x > drawLimits.x - ballRadius) { ballCoord.x = drawLimits.x - ballRadius };
    if ( ballCoord.y < ballRadius) {ballCoord.y = ballRadius};
    if ( ballCoord.y > drawLimits.y - ballRadius) { ballCoord.y = drawLimits.y - ballRadius };


    //debug.log('X', (ballCoord.y).toFixed(0));
    //debug.log('Y', (ballCoord.x).toFixed(0));

    // update the hero
    for (var h in heroes) {
        if (heroes[0]) {
            var hero = heroes[h];
            hero.moveHero();
            if (hero.checkCollision(ballCoord.x, ballCoord.y, ballRadius)) {
                if (hero.isSelf()) {
                    ballSpeed = Object.create(hero.getHitSpeed(drawLimits.x/2, drawLimits.y / 2));
                } else {
                    ballSpeed = Object.create(hero.getHitSpeed(drawLimits.x/2, drawLimits.y - 80));
                }
            }
        }
    }

    // check event zones
    if (fieldZones.length > 0) {
        for (var zone in fieldZones) {
            if (fieldZones[zone].checkCollision(ballCoord.x, ballCoord.y, ballRadius)){
                if (fieldZones[zone].eventType() == MessageQueue.EVENT_GOAL) {
                    centerTheBall();
                    score.increaseP1();
                } else if (fieldZones[zone].eventType() == MessageQueue.EVENT_BAR) {
                    ballCoord.x -= ballSpeed.x;
                    ballCoord.y -= ballSpeed.y;
                    ballSpeed.y = - ballSpeed.y;
                    ballSpeed.x = - ballSpeed.x;


                } else if (fieldZones[zone].eventType() == MessageQueue.EVENT_SELF_GOAL) {
                    centerTheBall();
                    score.increaseP2();
                }
            }
        }
    }

    // Check score & end the game
    if (score.p1() >= maxScore || score.p2() >= maxScore ) {
        gameOver();
    }

}

/*      Show debug message
 */
function debugMessage(ctx) {
    var statusString = debug.getString();
    debug.clear();

    ctx.font = "24px monospace";
    ctx.strokeStyle = "black";
    ctx.strokeText(statusString, 10, 20);
}


//////// End of drawing functions

// Game flow functions

function gameOver() {

    angular_scope.score = { p1 : score.p1(), p2 : score.p2()};
    angular_scope.showNewGameMessage();

}

/*
function showNewGameMessage() {
    gamePhase = 0;
    window.location.href = "#newGameMessage";
}

function startGame() {
    gamePhase = 1;
    window.location.href = "#";
    newGame();
}
*/     /// Old game flow functions

/*
 ****  Main execution area
 */
window.addEventListener("resize", resizeCanvas, false);
initDraw();             /// Init all the game state


/*
if ( gamePhase == 0 ) { // the game doesnt started
    // show new game screen
    angular_scope.showNewGameMessage();
} else if ( gamePhase = 1 ) {
    newGame();              // start a new game
}
*/

